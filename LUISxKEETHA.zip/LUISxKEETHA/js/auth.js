(function () {
  "use strict";

  const ADMIN_EMAIL = "ahamedyusoof07@gmil.com";
  const ADMIN_PASSWORD_HASH = "ba8ea4bff38fdee5eaa02c5d4be32497b1ebb0689eaaa09f9ff1bfaf6fd76c41";

  async function hashPassword(value) {
    const bytes = new TextEncoder().encode(value);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  function users() { return Store.get("users", []); }
  function session() { return Store.get("session", null); }
  function currentUser() { const active = session(); return active ? users().find((user) => user.id === active.userId) : null; }

  const adminDashboard = document.body.dataset.page === "admin";
  if (adminDashboard && session()?.role !== "admin") {
    document.documentElement.style.visibility = "hidden";
    location.replace("login.html?return=admin");
    return;
  }

  const registerForm = document.querySelector("[data-register-form]");
  registerForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!FormValidation.validateForm(registerForm)) return;
    const data = new FormData(registerForm);
    if (data.get("password") !== data.get("confirmPassword")) {
      const error = registerForm.querySelector("[data-confirm-error]"); error.textContent = "Passwords do not match."; return;
    }
    const email = FormValidation.sanitize(data.get("email")).toLowerCase();
    const allUsers = users();
    if (allUsers.some((user) => user.email === email)) { showToast("An account with that email already exists.", "error"); return; }
    const user = { id: `USR-${Date.now()}`, name: FormValidation.sanitize(data.get("name")), email, phone: FormValidation.sanitize(data.get("phone")), passwordHash: await hashPassword(data.get("password")), createdAt: new Date().toISOString() };
    allUsers.push(user); Store.set("users", allUsers); Store.set("session", { userId: user.id, createdAt: new Date().toISOString() });
    showToast("Demo account created. Welcome!"); setTimeout(() => { location.href = "dashboard.html"; }, 600);
  });

  const loginForm = document.querySelector("[data-login-form]");
  const adminLoginRequested = new URLSearchParams(location.search).get("return") === "admin";
  if (loginForm && adminLoginRequested) {
    const notice = document.createElement("div");
    notice.className = "notice";
    notice.textContent = "Administrator sign-in is required to open the admin dashboard.";
    loginForm.before(notice);
  }
  loginForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!FormValidation.validateForm(loginForm)) return;
    const data = new FormData(loginForm); const email = FormValidation.sanitize(data.get("email")).toLowerCase();
    const passwordHash = await hashPassword(data.get("password"));
    if (email === ADMIN_EMAIL && passwordHash === ADMIN_PASSWORD_HASH) {
      Store.set("session", { userId: "ADMIN", role: "admin", createdAt: new Date().toISOString() });
      showToast("Administrator access granted.");
      setTimeout(() => { location.href = "admin.html"; }, 500);
      return;
    }
    const user = users().find((entry) => entry.email === email && entry.passwordHash === passwordHash);
    if (!user) { showToast("Email or password is incorrect.", "error"); return; }
    if (adminLoginRequested) { showToast("This account does not have administrator access.", "error"); return; }
    Store.set("session", { userId: user.id, role: "user", createdAt: new Date().toISOString() }); showToast(`Welcome back, ${user.name}.`); setTimeout(() => { location.href = "dashboard.html"; }, 500);
  });

  const forgotForm = document.querySelector("[data-forgot-form]");
  forgotForm?.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!FormValidation.validateForm(forgotForm)) return;
    forgotForm.reset(); forgotForm.querySelector(".success-message").classList.add("show");
    showToast("Demo recovery request accepted. No email was sent.");
  });

  document.querySelectorAll("[data-auth-switch]").forEach((button) => button.addEventListener("click", (event) => {
    event.preventDefault();
    document.querySelector("[data-login-view]")?.toggleAttribute("hidden");
    document.querySelector("[data-forgot-view]")?.toggleAttribute("hidden");
  }));

  document.querySelectorAll("[data-logout]").forEach((button) => button.addEventListener("click", () => { Store.remove("session"); showToast("You have been signed out."); setTimeout(() => { location.href = "index.html"; }, 450); }));

  const dashboard = document.querySelector("[data-user-dashboard]");
  if (dashboard) {
    const user = currentUser();
    dashboard.querySelectorAll("[data-user-name]").forEach((node) => { node.textContent = user?.name || "Guest shopper"; });
    dashboard.querySelector("[data-user-status]").textContent = user ? `Signed in as ${user.email}` : "Demo guest view — create an account to save a profile.";
    const orders = Store.get("orders", []);
    const bookings = Store.get("bookings", []);
    dashboard.querySelector("[data-user-orders]").textContent = String(orders.length);
    dashboard.querySelector("[data-user-bookings]").textContent = String(bookings.length);
    dashboard.querySelector("[data-user-spend]").textContent = formatCurrency(orders.reduce((sum, order) => sum + Number(order.total || 0), 0));
    const orderTable = dashboard.querySelector("[data-user-order-list]");
    orderTable.innerHTML = orders.length ? orders.slice(0, 8).map((order) => `<tr><td>${FormValidation.sanitize(order.id)}</td><td>${new Date(order.createdAt).toLocaleDateString()}</td><td>${order.items.length} item(s)</td><td>${formatCurrency(order.total)}</td><td><span class="status">${FormValidation.sanitize(order.status)}</span></td></tr>`).join("") : `<tr><td colspan="5" class="muted">No demo orders yet.</td></tr>`;
    const profileForm = dashboard.querySelector("[data-profile-form]");
    if (user) { profileForm.elements.name.value = user.name; profileForm.elements.email.value = user.email; profileForm.elements.phone.value = user.phone || ""; }
    profileForm.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!FormValidation.validateForm(profileForm)) return;
      if (!user) { showToast("Create or sign into a demo account first.", "error"); return; }
      const data = new FormData(profileForm); const allUsers = users(); const record = allUsers.find((entry) => entry.id === user.id);
      record.name = FormValidation.sanitize(data.get("name")); record.email = FormValidation.sanitize(data.get("email")).toLowerCase(); record.phone = FormValidation.sanitize(data.get("phone"));
      Store.set("users", allUsers); showToast("Profile updated in this browser."); dashboard.querySelectorAll("[data-user-name]").forEach((node) => { node.textContent = record.name; });
    });
  }

  window.AuthDemo = { currentUser, hashPassword };
})();
