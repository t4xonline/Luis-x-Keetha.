(function () {
  "use strict";

  const cartRoot = document.querySelector("[data-cart-root]");
  if (!cartRoot) return;
  let discountRate = 0;

  function cartItems() {
    return Store.get("cart", []).map((item) => ({ ...item, product: ProductStore.byId(item.id) })).filter((item) => item.product);
  }

  function totals() {
    const subtotal = cartItems().reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const delivery = subtotal === 0 || subtotal >= 150 ? 0 : Number(getSiteSettings().deliveryFee || 8);
    const discount = subtotal * discountRate;
    return { subtotal, delivery, discount, total: subtotal + delivery - discount };
  }

  function render() {
    const items = cartItems();
    const { subtotal, delivery, discount, total } = totals();
    const itemsTarget = cartRoot.querySelector("[data-cart-items]");
    itemsTarget.innerHTML = items.length ? items.map(({ product, quantity }) => `<article class="cart-item card">
      <img src="${product.image}" alt="${FormValidation.sanitize(product.name)}" width="120" height="120">
      <div><span class="tag">${FormValidation.sanitize(product.category)}</span><h3 style="margin:8px 0">${FormValidation.sanitize(product.name)}</h3><strong>${formatCurrency(product.price)}</strong><button class="delete-button" type="button" data-cart-remove="${product.id}" aria-label="Remove ${FormValidation.sanitize(product.name)}">Remove</button></div>
      <div class="quantity"><button type="button" data-cart-decrease="${product.id}" aria-label="Decrease ${FormValidation.sanitize(product.name)} quantity">−</button><span>${quantity}</span><button type="button" data-cart-increase="${product.id}" aria-label="Increase ${FormValidation.sanitize(product.name)} quantity">+</button></div>
    </article>`).join("") : `<div class="card empty-state"><div class="empty-icon">◫</div><h2>Your cart is ready for something good.</h2><p class="muted">Browse the collection and add your favourites.</p><a class="btn btn-primary" href="products.html">Explore products</a></div>`;
    cartRoot.querySelector("[data-subtotal]").textContent = formatCurrency(subtotal);
    cartRoot.querySelector("[data-delivery]").textContent = delivery ? formatCurrency(delivery) : "Free";
    cartRoot.querySelector("[data-discount]").textContent = `−${formatCurrency(discount)}`;
    cartRoot.querySelector("[data-total]").textContent = formatCurrency(total);
    cartRoot.querySelector("[data-checkout-open]").disabled = !items.length;
    updateCartCount();
  }

  function mutate(id, action) {
    const cart = Store.get("cart", []);
    const item = cart.find((entry) => Number(entry.id) === Number(id));
    if (!item) return;
    if (action === "increase") item.quantity = Math.min(20, Number(item.quantity) + 1);
    if (action === "decrease") item.quantity = Math.max(1, Number(item.quantity) - 1);
    Store.set("cart", action === "remove" ? cart.filter((entry) => Number(entry.id) !== Number(id)) : cart); render();
  }

  cartRoot.addEventListener("click", (event) => {
    const plus = event.target.closest("[data-cart-increase]"); if (plus) mutate(plus.dataset.cartIncrease, "increase");
    const minus = event.target.closest("[data-cart-decrease]"); if (minus) mutate(minus.dataset.cartDecrease, "decrease");
    const remove = event.target.closest("[data-cart-remove]"); if (remove) { mutate(remove.dataset.cartRemove, "remove"); showToast("Item removed from your cart."); }
  });

  const discountForm = cartRoot.querySelector("[data-discount-form]");
  discountForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const code = new FormData(discountForm).get("discount").trim().toUpperCase();
    if (code === "SAVE10") { discountRate = .1; showToast("10% demo discount applied."); }
    else { discountRate = 0; showToast("That code is not valid. Try SAVE10.", "error"); }
    render();
  });

  const modal = document.querySelector("[data-checkout-modal]");
  const openModal = () => { modal.classList.add("open"); modal.setAttribute("aria-hidden", "false"); document.body.classList.add("no-scroll"); modal.querySelector("input")?.focus(); };
  const closeModal = () => { modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true"); document.body.classList.remove("no-scroll"); };
  cartRoot.querySelector("[data-checkout-open]").addEventListener("click", openModal);
  modal.querySelector("[data-modal-close]").addEventListener("click", closeModal);
  modal.addEventListener("click", (event) => { if (event.target === modal) closeModal(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape" && modal.classList.contains("open")) closeModal(); });

  modal.querySelector("form").addEventListener("submit", (event) => {
    event.preventDefault(); const form = event.currentTarget;
    if (!FormValidation.validateForm(form)) return;
    const values = Object.fromEntries([...new FormData(form)].map(([key, value]) => [key, FormValidation.sanitize(value)]));
    const currentItems = cartItems(); const currentTotals = totals();
    const orders = Store.get("orders", []);
    const order = { id: `LXK-${String(Date.now()).slice(-6)}`, items: currentItems.map(({ product, quantity }) => ({ id: product.id, name: product.name, quantity, price: product.price })), total: currentTotals.total, customer: values, status: "Confirmed (demo)", createdAt: new Date().toISOString() };
    orders.unshift(order); Store.set("orders", orders); Store.set("cart", []); form.reset(); closeModal(); render();
    document.querySelector("[data-order-success]").innerHTML = `<div class="success-message show"><strong>Demo order ${order.id} confirmed.</strong> No payment was processed. Your order is saved only in this browser.</div>`;
    document.querySelector("[data-order-success]").scrollIntoView({ behavior: "smooth", block: "center" });
  });

  const bookingForm = document.querySelector("[data-booking-form]");
  const dateInput = bookingForm.querySelector('input[type="date"]');
  dateInput.min = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const requestedProduct = new URLSearchParams(location.search).get("book");
  if (requestedProduct) {
    const product = ProductStore.byId(requestedProduct);
    if (product) bookingForm.querySelector("[name=service]").value = `Product consultation — ${product.name}`;
  }
  bookingForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!FormValidation.validateForm(bookingForm)) return;
    const values = Object.fromEntries([...new FormData(bookingForm)].map(([key, value]) => [key, FormValidation.sanitize(value)]));
    const bookings = Store.get("bookings", []); bookings.unshift({ id: `BK-${String(Date.now()).slice(-6)}`, ...values, status: "Requested", createdAt: new Date().toISOString() }); Store.set("bookings", bookings);
    bookingForm.reset(); dateInput.min = new Date(Date.now() + 86400000).toISOString().slice(0, 10); bookingForm.querySelector(".success-message").classList.add("show"); showToast("Booking request saved in this browser.");
  });

  render();
})();
