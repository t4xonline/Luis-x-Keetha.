(function () {
  "use strict";
  const canvas = document.getElementById("hero-canvas");
  if (!canvas) return;
  const fallback = document.querySelector(".webgl-fallback");
  const lowPower = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!window.WebGLRenderingContext || !window.THREE) { canvas.hidden = true; if (fallback) fallback.style.display = "grid"; return; }
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas, antialias: !lowPower, alpha: true, powerPreference: lowPower ? "low-power" : "high-performance" }); }
  catch (error) { console.warn("3D preview unavailable.", error); canvas.hidden = true; if (fallback) fallback.style.display = "grid"; return; }

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(42, 1, .1, 100); camera.position.set(0, .3, 6.2);
  renderer.setPixelRatio(Math.min(devicePixelRatio, lowPower ? 1 : 1.7)); renderer.shadowMap.enabled = !lowPower; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const group = new THREE.Group(); scene.add(group);
  const mainGeometry = new THREE.TorusKnotGeometry(1.25, .42, lowPower ? 80 : 150, lowPower ? 12 : 24, 2, 3);
  const material = new THREE.MeshStandardMaterial({ color: 0xff6b5f, metalness: .42, roughness: .24, emissive: 0x240604, emissiveIntensity: .12 });
  const object = new THREE.Mesh(mainGeometry, material); object.castShadow = true; object.receiveShadow = true; group.add(object);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.05, .028, 8, 120), new THREE.MeshBasicMaterial({ color: 0x7aa6ce, transparent: true, opacity: .55 })); ring.rotation.x = 1.18; group.add(ring);
  const ring2 = ring.clone(); ring2.scale.setScalar(.75); ring2.rotation.set(.3, 1.2, .1); group.add(ring2);
  const ambient = new THREE.HemisphereLight(0xc4dcff, 0x071426, 1.35); scene.add(ambient);
  const key = new THREE.DirectionalLight(0xffffff, 2.4); key.position.set(4, 5, 5); key.castShadow = !lowPower; scene.add(key);
  const coral = new THREE.PointLight(0xff6b5f, 2.2, 12); coral.position.set(-3, -1, 3); scene.add(coral);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.ShadowMaterial({ opacity: .22 })); floor.rotation.x = -Math.PI / 2; floor.position.y = -2.1; floor.receiveShadow = true; scene.add(floor);
  const particleCount = lowPower ? 70 : 180; const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < positions.length; i += 3) { positions[i] = (Math.random() - .5) * 10; positions[i + 1] = (Math.random() - .5) * 8; positions[i + 2] = (Math.random() - .5) * 7; }
  const particlesGeometry = new THREE.BufferGeometry(); particlesGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const particles = new THREE.Points(particlesGeometry, new THREE.PointsMaterial({ color: 0xffffff, size: .025, transparent: true, opacity: .55 })); scene.add(particles);
  let pointerX = 0, pointerY = 0, dragging = false, lastX = 0;
  canvas.addEventListener("pointerdown", (event) => { dragging = true; lastX = event.clientX; canvas.setPointerCapture(event.pointerId); });
  canvas.addEventListener("pointermove", (event) => {
    const rect = canvas.getBoundingClientRect(); pointerX = ((event.clientX - rect.left) / rect.width - .5) * 2; pointerY = ((event.clientY - rect.top) / rect.height - .5) * 2;
    if (dragging) { group.rotation.y += (event.clientX - lastX) * .012; lastX = event.clientX; }
  });
  canvas.addEventListener("pointerup", () => { dragging = false; }); canvas.addEventListener("pointercancel", () => { dragging = false; });
  function resize() { const rect = canvas.getBoundingClientRect(); if (!rect.width || !rect.height) return; camera.aspect = rect.width / rect.height; camera.updateProjectionMatrix(); renderer.setSize(rect.width, rect.height, false); }
  const observer = new ResizeObserver(resize); observer.observe(canvas); resize();
  let running = true, start = performance.now();
  document.addEventListener("visibilitychange", () => { running = !document.hidden; if (running) { start = performance.now(); requestAnimationFrame(render); } });
  function render(time) {
    if (!running) return; const elapsed = (time - start) / 1000;
    if (!dragging) group.rotation.y += lowPower ? .0015 : .0035;
    group.rotation.x += (pointerY * .18 - group.rotation.x) * .025; group.position.x += (pointerX * .25 - group.position.x) * .025;
    object.position.y = Math.sin(elapsed * 1.2) * .12; ring.rotation.z += .0018; ring2.rotation.y -= .0023; particles.rotation.y = elapsed * .018;
    const scrollProgress = Math.min(1, scrollY / innerHeight); camera.position.z = 6.2 + scrollProgress * .7; camera.position.y = .3 - scrollProgress * .35; camera.lookAt(0, 0, 0);
    renderer.render(scene, camera); requestAnimationFrame(render);
  }
  requestAnimationFrame(render);
})();
