(function () {
  "use strict";

  const DEFAULT_SETTINGS = {
    email: "hello@luisxkeetha.example",
    phone: "+1 (555) 014-8820",
    address: "18 Coral Avenue, Harbor District",
    hours: "Mon–Sat, 9:00 AM–7:00 PM",
    deliveryFee: 8,
    announcement: "Free delivery on orders over $150"
  };

  window.Store = {
    get(key, fallback) {
      try {
        const value = localStorage.getItem(`lxk_${key}`);
        return value === null ? fallback : JSON.parse(value);
      } catch (error) {
        console.warn(`Could not read ${key} from local storage.`, error);
        return fallback;
      }
    },
    set(key, value) {
      try { localStorage.setItem(`lxk_${key}`, JSON.stringify(value)); return true; }
      catch (error) { console.warn(`Could not save ${key}.`, error); return false; }
    },
    remove(key) { localStorage.removeItem(`lxk_${key}`); }
  };

  window.getSiteSettings = () => ({ ...DEFAULT_SETTINGS, ...Store.get("settings", {}) });

  const page = document.body.dataset.page || "home";
  const navItems = [
    ["home", "Home", "index.html"],
    ["about", "About", "about.html"],
    ["products", "Products", "products.html"],
    ["contact", "Contact", "contact.html"]
  ];

  function icon(name, label = "") {
    const symbols = { menu: "☰", theme: "◐", cart: "◫", user: "◎", top: "↑", close: "×" };
    return `<span aria-hidden="true">${symbols[name] || "•"}</span>${label ? `<span class="sr-only">${label}</span>` : ""}`;
  }

  function renderHeader() {
    const target = document.querySelector("[data-site-header]");
    if (!target) return;
    target.outerHTML = `
      <header class="site-header" data-site-header>
        <div class="container nav-wrap">
          <a class="brand" href="index.html" aria-label="LUISxKEETHA home">
            <span class="brand-mark" aria-hidden="true">LK</span><span class="brand-text">LUISxKEETHA</span>
          </a>
          <nav class="main-nav" id="main-nav" aria-label="Main navigation">
            ${navItems.map(([id, label, href]) => `<a href="${href}" class="${page === id ? "active" : ""}">${label}</a>`).join("")}
            <a href="cart.html" class="${page === "cart" ? "active" : ""}">Cart & booking</a>
            <a href="dashboard.html" class="${page === "dashboard" ? "active" : ""}">Dashboard</a>
          </nav>
          <div class="nav-actions">
            <button class="icon-btn" type="button" data-theme-toggle aria-label="Switch colour theme">${icon("theme")}</button>
            <a class="icon-btn cart-link" href="cart.html" aria-label="View cart">${icon("cart")}<span class="cart-count" data-cart-count>0</span></a>
            <a class="btn btn-primary btn-small desktop-only" href="login.html">Sign in</a>
            <button class="icon-btn menu-toggle" type="button" aria-controls="main-nav" aria-expanded="false" aria-label="Open menu">${icon("menu")}</button>
          </div>
        </div>
      </header>`;
  }

  function renderFooter() {
    const target = document.querySelector("[data-site-footer]");
    if (!target) return;
    const settings = getSiteSettings();
    target.outerHTML = `
      <footer class="site-footer" data-site-footer>
        <div class="container">
          <div class="footer-grid">
            <div class="footer-brand">
              <a class="brand" href="index.html"><span class="brand-mark" aria-hidden="true">LK</span><span>LUISxKEETHA</span></a>
              <p>Considered products, expressive design and an easy shopping experience—all brought together in one modern collection.</p>
              <div class="socials" aria-label="Social media">
                ${socialLinks()}
              </div>
            </div>
            <div><h3 class="footer-title">Explore</h3><div class="footer-links"><a href="about.html">Our story</a><a href="products.html">All products</a><a href="product-details.html?id=1">Featured item</a><a href="contact.html">Contact</a></div></div>
            <div><h3 class="footer-title">Account</h3><div class="footer-links"><a href="login.html">Sign in</a><a href="register.html">Create account</a><a href="dashboard.html">User dashboard</a><a href="admin.html">Admin demo</a></div></div>
            <div><h3 class="footer-title">Information</h3><div class="footer-links"><a href="privacy.html">Privacy policy</a><a href="terms.html">Terms</a><a href="index.html#faq">FAQ</a><a href="404.html">404 preview</a></div></div>
          </div>
          <div class="footer-bottom"><span>© <span data-year></span> LUISxKEETHA. Demo storefront.</span><span>${settings.email} · ${settings.phone}</span></div>
        </div>
      </footer>`;
  }

  function socialLinks() {
    return [
      ["Facebook", "https://facebook.com"], ["Instagram", "https://instagram.com"], ["TikTok", "https://tiktok.com"],
      ["YouTube", "https://youtube.com"], ["LinkedIn", "https://linkedin.com"], ["X", "https://x.com"], ["Pinterest", "https://pinterest.com"]
    ].map(([name, url]) => `<a href="${url}" target="_blank" rel="noopener" aria-label="${name}">${name === "Instagram" ? "IG" : name.slice(0, 2)}</a>`).join("");
  }
  window.socialLinks = socialLinks;

  function renderLoader() {
    if (document.querySelector(".loader")) return;
    const loader = document.createElement("div");
    loader.className = "loader";
    loader.setAttribute("aria-hidden", "true");
    loader.innerHTML = `<div class="loader-inner"><div class="loader-orb"></div><strong>LUISxKEETHA</strong></div>`;
    document.body.prepend(loader);
    window.addEventListener("load", () => setTimeout(() => loader.classList.add("hidden"), 260), { once: true });
    setTimeout(() => loader.classList.add("hidden"), 1600);
  }

  function updateCartCount() {
    const count = Store.get("cart", []).reduce((sum, item) => sum + Number(item.quantity || 0), 0);
    document.querySelectorAll("[data-cart-count]").forEach((node) => { node.textContent = String(count); });
  }
  window.updateCartCount = updateCartCount;

  function toast(message, type = "success") {
    let wrap = document.querySelector(".toast-wrap");
    if (!wrap) {
      wrap = document.createElement("div"); wrap.className = "toast-wrap"; wrap.setAttribute("aria-live", "polite");
      document.body.append(wrap);
    }
    const node = document.createElement("div");
    node.className = `toast ${type}`; node.textContent = message; wrap.append(node);
    setTimeout(() => node.remove(), 3500);
  }
  window.showToast = toast;

  function initTheme() {
    const saved = Store.get("theme", "light");
    document.documentElement.dataset.theme = saved;
    document.querySelectorAll("[data-theme-toggle]").forEach((button) => button.addEventListener("click", () => {
      const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = next; Store.set("theme", next);
      toast(`${next[0].toUpperCase() + next.slice(1)} mode enabled.`);
    }));
  }

  function initNavigation() {
    const header = document.querySelector(".site-header");
    const menu = document.querySelector(".main-nav");
    const toggle = document.querySelector(".menu-toggle");
    const onScroll = () => {
      header?.classList.toggle("scrolled", window.scrollY > 16);
      document.querySelector(".scroll-top")?.classList.toggle("visible", window.scrollY > 500);
    };
    onScroll(); window.addEventListener("scroll", onScroll, { passive: true });
    toggle?.addEventListener("click", () => {
      const open = menu.classList.toggle("open"); toggle.setAttribute("aria-expanded", String(open));
    });
    menu?.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => { menu.classList.remove("open"); toggle?.setAttribute("aria-expanded", "false"); }));
    const top = document.createElement("button"); top.type = "button"; top.className = "icon-btn scroll-top"; top.setAttribute("aria-label", "Scroll to top"); top.innerHTML = icon("top");
    top.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" })); document.body.append(top);
  }

  function initFaq() {
    document.querySelectorAll(".faq-question").forEach((button) => button.addEventListener("click", () => {
      const item = button.closest(".faq-item"); const open = item.classList.toggle("open"); button.setAttribute("aria-expanded", String(open));
    }));
  }

  function initForms() {
    document.querySelectorAll("[data-newsletter-form]").forEach((form) => form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!FormValidation.validateForm(form)) return;
      const email = FormValidation.sanitize(new FormData(form).get("email"));
      const subscribers = Store.get("subscribers", []);
      if (!subscribers.includes(email)) subscribers.push(email);
      Store.set("subscribers", subscribers); form.reset(); toast("You’re on the list. Welcome to LUISxKEETHA!");
    }));
    document.querySelectorAll("[data-contact-form]").forEach((form) => form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!FormValidation.validateForm(form)) return;
      const values = Object.fromEntries([...new FormData(form)].map(([key, value]) => [key, FormValidation.sanitize(value)]));
      const messages = Store.get("messages", []); messages.unshift({ ...values, id: Date.now(), createdAt: new Date().toISOString() }); Store.set("messages", messages);
      form.reset(); form.querySelector(".success-message")?.classList.add("show"); toast("Message saved in this browser. No email was sent.");
    }));
  }

  function bindSettings() {
    const settings = getSiteSettings();
    document.querySelectorAll("[data-setting]").forEach((node) => {
      const key = node.dataset.setting;
      if (Object.prototype.hasOwnProperty.call(settings, key)) node.textContent = String(settings[key]);
    });
  }

  function initMotion() {
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!reduce && window.gsap) {
      gsap.from("[data-reveal]", { opacity: 0, y: 28, duration: .85, stagger: .09, ease: "power3.out" });
      if (window.ScrollTrigger) {
        gsap.registerPlugin(ScrollTrigger);
        document.querySelectorAll("[data-scroll-reveal]").forEach((node) => gsap.from(node, { scrollTrigger: { trigger: node, start: "top 88%" }, opacity: 0, y: 36, duration: .75 }));
      }
    }
    document.querySelectorAll("[data-depth]").forEach((card) => {
      card.addEventListener("pointermove", (event) => {
        if (reduce) return;
        const rect = card.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / rect.width - .5) * 7;
        const y = ((event.clientY - rect.top) / rect.height - .5) * -7;
        card.style.transform = `perspective(800px) rotateX(${y}deg) rotateY(${x}deg) translateY(-5px)`;
      });
      card.addEventListener("pointerleave", () => { card.style.transform = ""; });
    });
  }

  renderLoader(); renderHeader(); renderFooter(); initTheme(); initNavigation(); initFaq(); initForms(); bindSettings(); updateCartCount();
  document.querySelectorAll("[data-year]").forEach((node) => { node.textContent = String(new Date().getFullYear()); });
  window.addEventListener("storage", updateCartCount);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initMotion); else initMotion();
})();
