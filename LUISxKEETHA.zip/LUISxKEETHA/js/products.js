(function () {
  "use strict";

  const defaults = [
    { id: 1, name: "Aero Form Watch", category: "Accessories", description: "A sculptural timepiece with a brushed steel case, coral detail and soft-touch strap.", price: 129, rating: 4.9, available: true, featured: true, image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1000&q=82" },
    { id: 2, name: "Halo Studio Headphones", category: "Technology", description: "Immersive wireless sound, refined controls and all-day comfort in a minimal silhouette.", price: 189, rating: 4.8, available: true, featured: true, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1000&q=82" },
    { id: 3, name: "Drift Runner", category: "Lifestyle", description: "A lightweight everyday sneaker designed for clean lines, movement and lasting comfort.", price: 98, rating: 4.7, available: true, featured: true, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1000&q=82" },
    { id: 4, name: "Contour Lounge Chair", category: "Home", description: "A modern lounge chair with balanced proportions and a warm, inviting profile.", price: 340, rating: 4.9, available: true, featured: false, image: "https://images.unsplash.com/photo-1567538096630-e0c5760a2e5b?auto=format&fit=crop&w=1000&q=82" },
    { id: 5, name: "Frame Mini Camera", category: "Technology", description: "A compact creative companion with tactile controls and a timeless matte finish.", price: 520, rating: 4.6, available: true, featured: false, image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1000&q=82" },
    { id: 6, name: "Nomad Daypack", category: "Accessories", description: "Weather-ready storage with a flexible interior for commutes, travel and daily carry.", price: 76, rating: 4.8, available: true, featured: false, image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1000&q=82" },
    { id: 7, name: "Arc Table Light", category: "Home", description: "Soft ambient illumination from a compact lamp with a beautifully curved form.", price: 115, rating: 4.5, available: true, featured: false, image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1000&q=82" },
    { id: 8, name: "Terra Steel Bottle", category: "Lifestyle", description: "Double-wall insulation, a leak-resistant lid and a durable powder-coated finish.", price: 38, rating: 4.7, available: false, featured: false, image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=1000&q=82" }
  ];

  function getProducts() {
    const saved = Store.get("products", null);
    if (!Array.isArray(saved) || !saved.length) { Store.set("products", defaults); return [...defaults]; }
    return saved;
  }

  function saveProducts(products) { Store.set("products", products); }
  function byId(id) { return getProducts().find((product) => Number(product.id) === Number(id)); }

  window.ProductStore = { defaults, getProducts, saveProducts, byId };

  function currency(value) { return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(value); }
  window.formatCurrency = currency;

  function productCard(product) {
    return `<article class="product-card" data-depth data-product-id="${product.id}">
      <div class="product-media">
        <img src="${product.image}" alt="${FormValidation.sanitize(product.name)}" loading="lazy" width="700" height="540">
        <span class="pill product-badge">${product.available ? "In stock" : "Sold out"}</span>
      </div>
      <div class="product-body">
        <div class="product-topline"><span>${FormValidation.sanitize(product.category)}</span><span><span class="star">★</span> ${Number(product.rating).toFixed(1)}</span></div>
        <h3>${FormValidation.sanitize(product.name)}</h3>
        <p>${FormValidation.sanitize(product.description)}</p>
        <div class="product-topline"><strong class="product-price">${currency(product.price)}</strong><span>${product.available ? "Ready to ship" : "Join waitlist"}</span></div>
        <div class="product-actions">
          <button class="btn btn-primary" type="button" data-add-to-cart="${product.id}" ${product.available ? "" : "disabled"}>Add to cart</button>
          <a class="btn btn-secondary" href="product-details.html?id=${product.id}" aria-label="View ${FormValidation.sanitize(product.name)} details">View</a>
        </div>
      </div>
    </article>`;
  }

  function addToCart(id, quantity = 1) {
    const product = byId(id);
    if (!product || !product.available) { showToast("This product is currently unavailable.", "error"); return; }
    const cart = Store.get("cart", []);
    const existing = cart.find((item) => Number(item.id) === Number(id));
    if (existing) existing.quantity += Number(quantity);
    else cart.push({ id: product.id, quantity: Number(quantity) });
    Store.set("cart", cart); updateCartCount(); showToast(`${product.name} added to your cart.`);
  }
  window.addToCart = addToCart;

  function renderFeatured() {
    document.querySelectorAll("[data-featured-products]").forEach((target) => {
      target.innerHTML = getProducts().filter((product) => product.featured).slice(0, 3).map(productCard).join("");
    });
  }

  function renderCatalog() {
    const target = document.querySelector("[data-product-grid]");
    if (!target) return;
    const search = document.querySelector("[data-product-search]");
    const category = document.querySelector("[data-category-filter]");
    const price = document.querySelector("[data-price-filter]");
    const sort = document.querySelector("[data-product-sort]");
    const resultCount = document.querySelector("[data-result-count]");
    const categories = [...new Set(getProducts().map((product) => product.category))].sort();
    category.innerHTML = `<option value="all">All categories</option>${categories.map((item) => `<option value="${item}">${item}</option>`).join("")}`;

    const update = () => {
      const query = search.value.trim().toLowerCase();
      const maxPrice = Number(price.value);
      let products = getProducts().filter((product) => {
        const matchesText = `${product.name} ${product.description} ${product.category}`.toLowerCase().includes(query);
        return matchesText && (category.value === "all" || product.category === category.value) && product.price <= maxPrice;
      });
      if (sort.value === "price-low") products.sort((a, b) => a.price - b.price);
      if (sort.value === "price-high") products.sort((a, b) => b.price - a.price);
      if (sort.value === "rating") products.sort((a, b) => b.rating - a.rating);
      if (sort.value === "name") products.sort((a, b) => a.name.localeCompare(b.name));
      resultCount.textContent = `${products.length} product${products.length === 1 ? "" : "s"}`;
      target.innerHTML = products.length ? products.map(productCard).join("") : `<div class="card empty-state" style="grid-column:1/-1"><div class="empty-icon">⌕</div><h3>No products found</h3><p class="muted">Try a different search or filter.</p></div>`;
    };
    [search, category, price, sort].forEach((control) => control.addEventListener("input", update)); update();
  }

  function renderDetails() {
    const target = document.querySelector("[data-product-details]");
    if (!target) return;
    const id = new URLSearchParams(location.search).get("id") || 1;
    const product = byId(id);
    if (!product) { location.replace("404.html"); return; }
    document.title = `${product.name} | LUISxKEETHA`;
    target.innerHTML = `<div class="detail-grid">
      <div class="detail-image" data-rotate-preview aria-label="Drag to preview ${FormValidation.sanitize(product.name)} in 360 degrees">
        <img src="${product.image}" alt="${FormValidation.sanitize(product.name)} product preview" width="900" height="1000">
        <span class="hero-visual-label">Drag or swipe to rotate preview</span>
      </div>
      <div class="detail-copy">
        <p class="eyebrow">${FormValidation.sanitize(product.category)}</p>
        <h1 style="font-size:clamp(3rem,6vw,5rem)">${FormValidation.sanitize(product.name)}</h1>
        <div class="actions"><span class="star">★★★★★</span><span class="muted">${Number(product.rating).toFixed(1)} · 84 verified reviews</span></div>
        <p class="detail-price">${currency(product.price)}</p>
        <p class="lede">${FormValidation.sanitize(product.description)} Crafted for people who value useful details, expressive form and quality that lasts.</p>
        <p class="availability">${product.available ? "Available and ready to ship" : "Currently unavailable"}</p>
        <ul class="check-list"><li>Free returns within 30 days</li><li>One-year limited product warranty</li><li>Tracked delivery and careful packaging</li></ul>
        <div class="actions" style="align-items:center">
          <div class="quantity" aria-label="Quantity"><button type="button" data-detail-minus aria-label="Decrease quantity">−</button><span data-detail-quantity>1</span><button type="button" data-detail-plus aria-label="Increase quantity">+</button></div>
          <button class="btn btn-primary" type="button" data-detail-add ${product.available ? "" : "disabled"}>Add to cart</button>
          <button class="btn btn-secondary" type="button" data-detail-book>Book a consultation</button>
        </div>
        <div class="notice" style="margin-top:25px">Checkout and payment are simulated in this demonstration. No real charge will be made.</div>
      </div>
    </div>`;
    let quantity = 1;
    const quantityNode = target.querySelector("[data-detail-quantity]");
    target.querySelector("[data-detail-minus]").addEventListener("click", () => { quantity = Math.max(1, quantity - 1); quantityNode.textContent = quantity; });
    target.querySelector("[data-detail-plus]").addEventListener("click", () => { quantity = Math.min(20, quantity + 1); quantityNode.textContent = quantity; });
    target.querySelector("[data-detail-add]").addEventListener("click", () => addToCart(product.id, quantity));
    target.querySelector("[data-detail-book]").addEventListener("click", () => { location.href = `cart.html?book=${product.id}`; });
    initRotation(target.querySelector("[data-rotate-preview]"));
  }

  function initRotation(area) {
    if (!area) return;
    let dragging = false, start = 0, rotation = 0;
    const move = (event) => { if (!dragging) return; const x = event.clientX ?? event.touches?.[0]?.clientX; rotation += (x - start) * .18; start = x; area.style.setProperty("--rotate", `${Math.max(-22, Math.min(22, rotation))}deg`); };
    area.addEventListener("pointerdown", (event) => { dragging = true; start = event.clientX; area.setPointerCapture(event.pointerId); });
    area.addEventListener("pointermove", move);
    area.addEventListener("pointerup", () => { dragging = false; });
    area.addEventListener("pointercancel", () => { dragging = false; });
  }

  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-add-to-cart]");
    if (button) addToCart(button.dataset.addToCart);
  });

  renderFeatured(); renderCatalog(); renderDetails();
})();
