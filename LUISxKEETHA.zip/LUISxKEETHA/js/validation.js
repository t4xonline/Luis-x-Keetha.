(function () {
  "use strict";

  const rules = {
    required(value) { return String(value).trim() ? "" : "This field is required."; },
    email(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value).trim()) ? "" : "Enter a valid email address."; },
    phone(value) { return /^[+()\d\s-]{7,20}$/.test(String(value).trim()) ? "" : "Enter a valid phone number."; },
    password(value) { return /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(String(value)) ? "" : "Use at least 8 characters with a letter and number."; }
  };

  function sanitize(value) {
    const node = document.createElement("div");
    node.textContent = String(value ?? "").trim();
    return node.textContent;
  }

  function validateField(field) {
    const checks = (field.dataset.validate || "").split(" ").filter(Boolean);
    let message = "";
    for (const check of checks) {
      if (rules[check]) {
        message = rules[check](field.value);
        if (message) break;
      }
    }
    if (!message && field.minLength > 0 && field.value.length < field.minLength) {
      message = `Use at least ${field.minLength} characters.`;
    }
    const error = field.closest(".field")?.querySelector(".field-error");
    field.setAttribute("aria-invalid", String(Boolean(message)));
    if (error) error.textContent = message;
    return !message;
  }

  function validateForm(form) {
    return [...form.querySelectorAll("[data-validate]")].map(validateField).every(Boolean);
  }

  document.addEventListener("input", (event) => {
    if (event.target.matches("[data-validate]")) validateField(event.target);
  });

  window.FormValidation = { sanitize, validateField, validateForm };
})();
