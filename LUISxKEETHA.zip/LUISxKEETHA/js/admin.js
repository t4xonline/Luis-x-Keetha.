(function () {
  "use strict";
  const root = document.querySelector("[data-admin-dashboard]");
  if (!root) return;

  const tabs = [...root.querySelectorAll("[data-admin-tab]")];
  const sections = [...root.querySelectorAll("[data-admin-section]")];
  function openSection(name) {
    tabs.forEach((tab) => tab.classList.toggle("active", tab.dataset.adminTab === name));
    sections.forEach((section) => section.classList.toggle("active", section.dataset.adminSection === name));
  }
  tabs.forEach((tab) => tab.addEventListener("click", () => openSection(tab.dataset.adminTab)));

  function summary() {
    const products = ProductStore.getProducts(); const users = Store.get("users", []); const orders = Store.get("orders", []); const bookings = Store.get("bookings", []);
    root.querySelector("[data-admin-products]").textContent = String(products.length);
    root.querySelector("[data-admin-customers]").textContent = String(users.length);
    root.querySelector("[data-admin-orders]").textContent = String(orders.length + bookings.length);
    root.querySelector("[data-admin-revenue]").textContent = formatCurrency(orders.reduce((sum, order) => sum + Number(order.total || 0), 0));
  }

  const productTable = root.querySelector("[data-admin-product-list]");
  const productSearch = root.querySelector("[data-admin-product-search]");
  function renderProducts() {
    const query = productSearch.value.trim().toLowerCase();
    const products = ProductStore.getProducts().filter((product) => `${product.name} ${product.category}`.toLowerCase().includes(query));
    productTable.innerHTML = products.length ? products.map((product) => `<tr><td>${FormValidation.sanitize(product.name)}</td><td>${FormValidation.sanitize(product.category)}</td><td>${formatCurrency(product.price)}</td><td>${product.available ? '<span class="status">Available</span>' : '<span class="pill">Unavailable</span>'}</td><td><button type="button" class="edit-button" data-product-edit="${product.id}">Edit</button><button type="button" class="delete-button" data-product-delete="${product.id}">Delete</button></td></tr>`).join("") : `<tr><td colspan="5" class="muted">No products match this search.</td></tr>`;
  }
  productSearch.addEventListener("input", renderProducts);

  const modal = document.querySelector("[data-product-modal]");
  const productForm = modal.querySelector("form");
  function openProductModal(product = null) {
    productForm.reset(); productForm.elements.id.value = product?.id || ""; productForm.elements.name.value = product?.name || ""; productForm.elements.category.value = product?.category || ""; productForm.elements.description.value = product?.description || ""; productForm.elements.price.value = product?.price || ""; productForm.elements.rating.value = product?.rating || "4.5"; productForm.elements.image.value = product?.image || ""; productForm.elements.available.checked = product ? product.available : true; productForm.elements.featured.checked = product ? product.featured : false;
    modal.querySelector("[data-product-modal-title]").textContent = product ? "Edit product" : "Add product";
    modal.classList.add("open"); modal.setAttribute("aria-hidden", "false"); document.body.classList.add("no-scroll"); productForm.elements.name.focus();
  }
  function closeProductModal() { modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true"); document.body.classList.remove("no-scroll"); }
  root.querySelector("[data-add-product]").addEventListener("click", () => openProductModal());
  modal.querySelector("[data-modal-close]").addEventListener("click", closeProductModal);
  modal.addEventListener("click", (event) => { if (event.target === modal) closeProductModal(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape" && modal.classList.contains("open")) closeProductModal(); });
  productForm.addEventListener("submit", (event) => {
    event.preventDefault(); if (!FormValidation.validateForm(productForm)) return;
    const data = new FormData(productForm); const products = ProductStore.getProducts(); const id = Number(data.get("id")) || Date.now();
    const record = { id, name: FormValidation.sanitize(data.get("name")), category: FormValidation.sanitize(data.get("category")), description: FormValidation.sanitize(data.get("description")), price: Number(data.get("price")), rating: Number(data.get("rating")), image: FormValidation.sanitize(data.get("image")), available: data.get("available") === "on", featured: data.get("featured") === "on" };
    const existing = products.findIndex((product) => Number(product.id) === id);
    if (existing >= 0) products[existing] = record; else products.unshift(record);
    ProductStore.saveProducts(products); closeProductModal(); renderProducts(); summary(); showToast(existing >= 0 ? "Product updated." : "Product added.");
  });
  productTable.addEventListener("click", (event) => {
    const edit = event.target.closest("[data-product-edit]"); if (edit) openProductModal(ProductStore.byId(edit.dataset.productEdit));
    const remove = event.target.closest("[data-product-delete]");
    if (remove) {
      const product = ProductStore.byId(remove.dataset.productDelete);
      if (product && window.confirm(`Delete “${product.name}”? This removes it from this browser's demo data.`)) {
        ProductStore.saveProducts(ProductStore.getProducts().filter((entry) => Number(entry.id) !== Number(product.id))); renderProducts(); summary(); showToast("Product deleted.");
      }
    }
  });

  function renderOrders() {
    const orders = Store.get("orders", []); const bookings = Store.get("bookings", []);
    root.querySelector("[data-admin-order-list]").innerHTML = orders.length ? orders.map((order) => `<tr><td>${FormValidation.sanitize(order.id)}</td><td>${FormValidation.sanitize(order.customer?.name || "Guest")}</td><td>${formatCurrency(order.total)}</td><td><select data-order-status="${order.id}" aria-label="Update ${order.id} status"><option ${order.status.includes("Confirmed") ? "selected" : ""}>Confirmed (demo)</option><option ${order.status === "Preparing" ? "selected" : ""}>Preparing</option><option ${order.status === "Completed" ? "selected" : ""}>Completed</option></select></td><td>${new Date(order.createdAt).toLocaleDateString()}</td></tr>`).join("") : `<tr><td colspan="5" class="muted">No demo orders yet.</td></tr>`;
    root.querySelector("[data-admin-booking-list]").innerHTML = bookings.length ? bookings.map((booking) => `<tr><td>${FormValidation.sanitize(booking.id)}</td><td>${FormValidation.sanitize(booking.name)}</td><td>${FormValidation.sanitize(booking.service)}</td><td>${FormValidation.sanitize(booking.date)} ${FormValidation.sanitize(booking.time)}</td><td><span class="status">${FormValidation.sanitize(booking.status)}</span></td></tr>`).join("") : `<tr><td colspan="5" class="muted">No booking requests yet.</td></tr>`;
  }
  root.addEventListener("change", (event) => {
    if (!event.target.matches("[data-order-status]")) return;
    const orders = Store.get("orders", []); const order = orders.find((entry) => entry.id === event.target.dataset.orderStatus);
    if (order) { order.status = event.target.value; Store.set("orders", orders); showToast("Order status updated."); }
  });

  function renderCustomers() {
    const users = Store.get("users", []);
    root.querySelector("[data-admin-customer-list]").innerHTML = users.length ? users.map((user) => `<tr><td>${FormValidation.sanitize(user.name)}</td><td>${FormValidation.sanitize(user.email)}</td><td>${FormValidation.sanitize(user.phone || "—")}</td><td>${new Date(user.createdAt).toLocaleDateString()}</td></tr>`).join("") : `<tr><td colspan="4" class="muted">No demo customer accounts yet.</td></tr>`;
    const messages = Store.get("messages", []);
    root.querySelector("[data-admin-message-list]").innerHTML = messages.length ? messages.map((message) => `<tr><td>${FormValidation.sanitize(message.name)}</td><td>${FormValidation.sanitize(message.email)}</td><td>${FormValidation.sanitize(message.subject)}</td><td>${new Date(message.createdAt).toLocaleDateString()}</td></tr>`).join("") : `<tr><td colspan="4" class="muted">No contact messages yet.</td></tr>`;
  }

  const settingsForm = root.querySelector("[data-settings-form]");
  const settings = getSiteSettings();
  Object.keys(settings).forEach((key) => { if (settingsForm.elements[key]) settingsForm.elements[key].value = settings[key]; });
  settingsForm.addEventListener("submit", (event) => {
    event.preventDefault(); if (!FormValidation.validateForm(settingsForm)) return;
    const data = new FormData(settingsForm); const updated = {};
    for (const [key, value] of data) updated[key] = key === "deliveryFee" ? Number(value) : FormValidation.sanitize(value);
    Store.set("settings", updated); showToast("Site details updated. Refresh other open pages to see them.");
  });

  root.querySelector("[data-reset-demo]").addEventListener("click", () => {
    if (window.confirm("Reset products and editable site settings to their original demo values? Orders and accounts will stay intact.")) {
      ProductStore.saveProducts(ProductStore.defaults); Store.remove("settings"); settingsForm.reset(); renderProducts(); summary(); showToast("Catalog and site details reset.");
    }
  });

  summary(); renderProducts(); renderOrders(); renderCustomers(); openSection("overview");
})();
