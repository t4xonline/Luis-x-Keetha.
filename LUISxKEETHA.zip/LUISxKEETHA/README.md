# LUISxKEETHA

A complete, responsive, multi-page 3D storefront demonstration built with HTML5, CSS3, JavaScript, Three.js, GSAP and browser local storage. The visual system uses the requested navy-and-coral palette and supports light and dark modes.

## Project structure

```text
LUISxKEETHA/
├── index.html
├── about.html
├── products.html
├── product-details.html
├── contact.html
├── login.html
├── register.html
├── cart.html
├── dashboard.html
├── admin.html
├── privacy.html
├── terms.html
├── 404.html
├── .nojekyll
├── css/
│   ├── style.css
│   ├── responsive.css
│   └── admin.css
├── js/
│   ├── main.js
│   ├── three-scene.js
│   ├── products.js
│   ├── cart.js
│   ├── auth.js
│   ├── admin.js
│   └── validation.js
└── assets/
    ├── images/
    ├── icons/
    ├── videos/
    └── models/
```

## Run in VS Code

1. Open the `LUISxKEETHA` folder in Visual Studio Code.
2. Install the free **Live Server** extension by Ritwick Dey.
3. Right-click `index.html` and choose **Open with Live Server**.
4. Keep an internet connection available while testing. Three.js, GSAP, the Google font and sample Unsplash imagery are loaded from public CDNs.

Opening `index.html` directly also works for most features, but Live Server is recommended because it behaves more like real hosting.

## Main features

- Responsive full-screen Three.js hero with pointer/touch rotation, lighting, shadows, particles, camera motion and automatic resizing.
- WebGL failure fallback and a reduced-complexity mode for lower-power or reduced-motion devices.
- Product catalog with search, category and price filters, sorting, stock state, ratings and editable sample data.
- Product-details page with quantity controls and a drag/swipe product-preview effect.
- Local cart with quantity changes, removal, totals, delivery fee, `SAVE10` demo discount and persistent browser storage.
- Simulated checkout with validation and local order confirmation. No payment data is requested or processed.
- Consultation booking with date validation and local booking history.
- Demo registration, login, password-recovery state, logout and profile editing. Demo passwords are converted to a SHA-256 hash before local storage.
- User dashboard with local order history and profile information.
- Admin dashboard with metrics, product add/edit/delete, order-status editing, booking/customer/message views, sales visualization and editable business details.
- Validated contact and newsletter forms with clear local-only success messages.
- Dark/light themes, mobile navigation, keyboard focus, semantic landmarks, reduced-motion support and responsive layouts.

## Edit products and business details

Open `admin.html` in the website and sign in with the configured administrator account. The password is verified against a SHA-256 hash and is not stored as readable text in the project. The admin demonstration can:

- add, edit, search and delete products;
- change availability, rating, price, category and featured status;
- inspect demo orders, bookings, accounts and contact messages;
- edit the displayed business email, phone, address, hours and delivery fee;
- reset the catalog and settings to the original sample data.

Admin changes use local storage and affect only the same browser profile. Use the browser’s site-data controls to clear all demonstration data.

The configured administrator email is `ahamedyusoof07@gmil.com`. Keep the password private. This remains a front-end demonstration; replace it with server-side authentication and authorization before production use.

For permanent defaults, edit the `defaults` array in `js/products.js` and `DEFAULT_SETTINGS` in `js/main.js`.

## Replace images

The sample catalog uses image URLs in the `defaults` array in `js/products.js`.

To use local images:

1. Copy compressed `.webp`, `.avif`, `.jpg` or `.png` files into `assets/images/`.
2. Change each product’s `image` value to a relative path such as `assets/images/aero-watch.webp`.
3. Update the image `alt` text in the HTML for gallery and editorial images.
4. Keep product images close to a 4:3 or square ratio and preferably under 250 KB.

If you have previously opened the site, the catalog may already be in local storage. Use **Reset catalog & settings** in `admin.html`, or clear site data, to reload changed defaults.

## Replace the procedural 3D object or load a GLTF model

The current hero is generated in `js/three-scene.js`, so it needs no model download. To switch to a `.glb`/`.gltf` model:

1. Put the optimized model in `assets/models/`.
2. Add the free Three.js `GLTFLoader` script after the Three.js script in `index.html`. Match its version to the Three.js version.
3. In `js/three-scene.js`, replace the torus-knot mesh creation with `new THREE.GLTFLoader().load(...)`.
4. Add the loaded scene to `group`, normalize its size and centre, enable shadows on its meshes, and keep the existing fallback/error handling.
5. Aim for a `.glb` file below 3 MB, use compressed textures and test on a real mobile device.

## Demonstration features versus production services

Working front-end features:

- catalog, filtering, sorting and product details;
- cart, discount and totals;
- booking and checkout validation;
- theme preferences;
- demo accounts and hashed local passwords;
- editable admin data and dashboards;
- persistent browser-local records.

Require a real backend before launch:

- real payments, refunds, taxes and fulfilment;
- secure authentication, authorization and password reset email;
- shared accounts and data across devices;
- inventory synchronization;
- actual contact and newsletter delivery;
- confirmed bookings and calendar integration;
- protected admin access;
- server-side validation, logging, backups and privacy-request handling.

Never place payment secrets, email credentials or private API keys in these JavaScript files.

## Publish on GitHub Pages

1. Create an empty GitHub repository, for example `luisxkeetha`.
2. Upload the **contents** of this folder to the repository root. `index.html` must be at the root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then save.
6. GitHub will show the public Pages address after deployment, usually `https://YOUR-USERNAME.github.io/luisxkeetha/`.
7. Test navigation, mobile layouts, the 3D fallback and a fresh-browser session at the public URL.

The included `.nojekyll` file asks GitHub Pages to serve the folder as plain static files. No build step is required.

## Alternative hosting

- **Netlify:** drag this folder into the Netlify manual deployment screen. The publish directory is the folder root.
- **Vercel:** import the repository as a static project. No framework preset or build command is required; use the project root as the output.

## Before a real launch

Replace the sample contact information, social destinations, legal text, product data, imagery, testimonials and statistics. Connect a secure backend for authentication, orders, bookings, forms and payments. Review accessibility with keyboard and screen-reader testing, run performance checks on representative devices and obtain legal review for the policy pages.

## Free resources used

- Three.js for WebGL rendering
- GSAP and ScrollTrigger for motion
- Manrope from Google Fonts
- Sample photography from Unsplash

All third-party resources remain subject to their respective licences and terms.
